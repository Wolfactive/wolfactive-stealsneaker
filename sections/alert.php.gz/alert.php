<div id="snackbar">Vui lòng chọn size trước khi đặt hàng (*)</div>

<div id="viewQuickModal" class="Form__modal">
    <div class="modal--content bounce-in-top">
        <div class="close">&times;</div>
        <div id="modal__item"></div>
    </div>
</div>

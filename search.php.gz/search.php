<?php

get_header();

wp_rig()->print_styles( 'wp-rig-content' );

?>
	<main id="primary" class="site-main">

	</main><!-- #primary -->
<?php
get_sidebar();
get_footer();

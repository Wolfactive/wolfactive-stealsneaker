import 'assets/js/core/lib/jquery-3.4.1.min';
import 'assets/js/core/lib/slick.min';
import 'assets/js/core/lib/lazyload.min';
import 'assets/js/core/main/global';

jQuery(document).ready(function() {
  gandul();
  jQuery('#navBtn').click(function(){
    jQuery('#headerNavBar').toggleClass('active');
  });
})

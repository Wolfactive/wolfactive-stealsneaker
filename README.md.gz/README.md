# Wolfactive-WordPress-Base-Theme
Step 1: Clone source
Step 2: npm install 
Step 3: run npm build

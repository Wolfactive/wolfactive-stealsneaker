 <?php
 /**
 * template name: Home Page
 */
 get_header();
 get_footer();
?>
